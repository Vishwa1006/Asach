/**Scala  Program to find largest number among two numbers.*/

    object ExFindLargest {
       def main(args: Array[String]) {
          var number1=20;
          var number2=30;
          var x = 10;

          if( number1>number2){
             println("Largest number is:" + number1);
          }
          else{
              println("Largest number is:" + number2);
          }
       }
    }